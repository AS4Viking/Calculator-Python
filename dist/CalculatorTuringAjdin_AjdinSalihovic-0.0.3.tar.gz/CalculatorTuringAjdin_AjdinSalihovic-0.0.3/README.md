# Calculator with Python

This Python Calculator is made for the Python Mastery Module with Turing college.

What I have done with this calculator is add:
1. Adding
2. Subtracting
3. Multiplication
4. Division
5. Takes (n) root of a number
6. Reset memory

When you run the file under the src folder, you will be asked to add first, and then the 2nd number. The loop will continue to ask if you would like to get another calculation until you choose not to continue, then it exists.
The only difference is the 6th Reset memory. Reset memory just resets our memory and that is it.

Tests - tests are made for all of the above except the 6th one which resets memory. The tests are simply made to make sure that everything works as it should.

This calculator can be installed with ip on: https://pypi.org/project/CalculatorTuringAjdin-AjdinSalihovic/0.0.2/
